
<link rel="stylesheet" type="text/css" href="{{ asset('template') }}//files/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="{{ asset('template') }}//files/assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="{{ asset('template') }}//files/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">