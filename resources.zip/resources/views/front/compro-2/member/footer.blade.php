<footer class="footer-part bg-dark pt-9 pb-9">
    <div class="container">
        <div class="row justify-content-center justify-content-lg-start my-4">
            <div class="col-lg-6">
                <div class="text-center text-lg-start">
                    <p class="mb-0 mt-3 text-white">2024 &copy; Akamajobs. All rights reserved.</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="text-center text-lg-end">
                    <button type="button" class="btn btn-light-dark btn-circle me-3" style="background-color: #3c485c">
                        <i class="fs-5 ti ti-brand-facebook text-white"></i>
                    </button>
                    <button type="button" class="btn btn-light-dark btn-circle me-3" style="background-color: #3c485c">
                        <i class="fs-5 ti ti-brand-instagram text-white"></i>
                    </button>
                    <button type="button" class="btn btn-light-dark btn-circle me-3" style="background-color: #3c485c">
                        <i class="fs-5 ti ti-brand-linkedin text-white"></i>
                    </button>
                    <button type="button" class="btn btn-light-dark btn-circle" style="background-color: #3c485c">
                        <i class="fs-5 ti ti-brand-twitter text-white"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</footer>